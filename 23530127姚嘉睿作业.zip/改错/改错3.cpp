#include <stdio.h>
void main()
{
	int i,j,num;
int temp1,temp2;
	int a[7]={1,3,5,7,9,11};     
	for(i=0;i<6;i++)
		printf("%3d",a[i]);
	printf("\nInput insert number:");
	scanf("%d",&num);           
	if(num>a[5])
		a[6]=num;
	else
	{
		for(i=0;i<6;i++)
		{
			if(a[i]>num)			
			{
				temp1=a[i];
				a[i]=num;
				for(j=i+1;j<7;j++)    
				{	temp2=a[j];
					a[j]=temp1;
					temp1=temp2;
				}
				break;	
			}
		}
	}
}