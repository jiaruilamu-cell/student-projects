#include <stdio.h>
void main()
{
    char str1[100], str2[100];
    int i, s;
    printf("input string 1:");
    gets(str1);
    printf("input string 2:");
    gets(str2);
    i = 0;
    while ((str1[i] == str2[i]) && (str1[i] != '\0'))
        i++;
    s = str1[i] - str2[i];
    printf("%d", s);
}