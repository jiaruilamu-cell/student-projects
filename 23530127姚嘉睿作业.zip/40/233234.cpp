#include <stdio.h>
#include <stdlib.h>

void fun(char *s) 
{
    int i, j;
    for (i = 0, j = 0; s[i] != '\0'; i++) {
        if ((i + s[i]) % 2 == 0) 
		{
            s[j++] = s[i];
        }
    }
    s[j] = '\0';
}

int main() {
    FILE *fp1, *fp2;
    char i[80], nt[80];
    printf("Enter a string:");
    gets(i);
    fp1 = fopen("file1.txt", "w");
    if (fp1 == NULL) 
	{
        printf("Error opening file!");
        exit(1);
    }
    fputs(i, fp1);
    fclose(fp1);
    fp1 = fopen("file1.txt", "r");
    if (fp1 == NULL) 
	{
        printf("Error opening file!");
        exit(1);
    }
    fgets(i, sizeof(i), fp1);
    fclose(fp1);
    printf("The string is :%s", i);
    fun(i);
    printf("The string of changing is :%s", i);
    fp2 = fopen("file2.txt", "w");
    if (fp2 == NULL)
	{
        printf("Error opening file!");
        exit(1);
    }
    fputs(i, fp2);
    fclose(fp2);
    return 0;
}
