#include <stdio.h>
#include <stdlib.h>

void fun(char *s) {
    int i, j;
    for (i = 0, j = 0; s[i] != '\0'; i++) {
        if ((i + s[i]) % 2 == 0) {
            s[j++] = s[i];
        }
    }
    s[j] = '\0';
}

int main() {
    FILE *fp1, *fp2;
    char item[80], new_item[80];
    printf("Enter a string:");
    gets(item);
    fp1 = fopen("file1.txt", "w");
    if (fp1 == NULL) {
        printf("Error opening file!");
        exit(1);
    }
    fputs(item, fp1);
    fclose(fp1);
    fp1 = fopen("file1.txt", "r");
    if (fp1 == NULL) {
        printf("Error opening file!");
        exit(1);
    }
    fgets(item, sizeof(item), fp1);
    fclose(fp1);
    printf("The string is :%s", item);
    fun(item);
    printf("The string of changing is :%s", item);
    fp2 = fopen("file2.txt", "w");
    if (fp2 == NULL) {
        printf("Error opening file!");
        exit(1);
    }
    fputs(item, fp2);
    fclose(fp2);
    return 0;
}