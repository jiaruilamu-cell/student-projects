#include <stdio.h>
#include<string.h>
void insert(char *s, char f, char i) 
{
    char *p = s;
    while (*p != '\0') {
        if (*p == f) {
            char *end = s + strlen(s);
            while (end > p) {
                *(end + 1) = *end;
                end--;
            }
            *(p + 1) = i;
            break;
        }
        p++;
    }
}
 
int main() {
    char i[80];
    char t,o;
    printf("Enter a string:");
    gets(i);
    printf("The string is :%s", i);
    printf("Enter the character to be inserted after: ");
    scanf("%c", &t);
    getchar();
    printf("Enter the character to be inserted: ");
    scanf("%c", &o);
    insert(i,t,o);
    printf("The string of changing is :%s", i);
	return 0;
}